g++ -c -I/home/alhasan/Software/Cpp_Extra/vflib2/include/ max_common_sg.cpp
g++ -o max_common_sg max_common_sg.o -L/home/alhasan/Software/Cpp_Extra/vflib2/lib/ -lvf -lstdc++ -lm
